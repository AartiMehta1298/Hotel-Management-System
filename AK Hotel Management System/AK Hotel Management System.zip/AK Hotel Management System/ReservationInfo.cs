﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AK_Hotel_Management_System
{
    public partial class ReservationInfo : Form
    {
        public void populate()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string myquery = "select * from Reservation_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ResGridView.DataSource = ds.Tables[0];

            con.Close();
        }

        public ReservationInfo()
        {
            InitializeComponent();
        }
        public void fillRoomcombo()
        {

            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            string roomstate = "free";

            SqlCommand cmd = new SqlCommand("select RoomId from Room_tbl where RoomFree='"+roomstate+"'",con);
            SqlDataReader rdr;

            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RoomId", typeof(int));
            dt.Load(rdr);
            roomicb.ValueMember = "RoomId";
            roomicb.DataSource = dt;
            
            con.Close();

            populate();


        }
        public void fillClientCombo()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            con.Open();
            SqlCommand cmd = new SqlCommand("select ClientName from Client_tbl", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("ClientName", typeof(string));
            dt.Load(rdr);
            clientncb.ValueMember = "ClientName";
            clientncb.DataSource = dt;

            con.Close();
            populate();


        }
        DateTime today;
        private void ReservationInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'akhotelDataSet3.Reservation_tbl' table. You can move, or remove it, as needed.
            this.reservation_tblTableAdapter.Fill(this.akhotelDataSet3.Reservation_tbl);
            today = dateTimein.Value;
            fillRoomcombo();
            fillClientCombo();
            populate();
            timer1.Start();


        }

        private void dateTimein_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(dateTimein.Value, today);
            if (res < 0)
                MessageBox.Show("Wrong Date for Reservation ");
        }

        private void dateTimeOut_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(dateTimeOut.Value,dateTimein.Value);
            if (res < 0)
                MessageBox.Show("Wrong DateOut. Check once more ");

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Reservation_tbl values('" +ResId.Text + "','" + clientncb.SelectedValue.ToString() + "','" + roomicb.SelectedValue.ToString() + "','" + dateTimein.Value + "','" + dateTimeOut.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Reservation Added Successfully");
            con.Close();
            updateroomstate();

            populate();

        }
        public void updateroomstate()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string newstate = "busy";

            string Myquery = "Update Room_tbl set RoomFree ='" + newstate + "'where RoomId = '" +Convert.ToInt32(roomicb.SelectedValue.ToString()) + "'; ";
            SqlCommand cmd = new SqlCommand(Myquery, con);
            cmd.ExecuteNonQuery();
            //MessageBox.Show("Reservation  Successfully Edited");
            con.Close();
            
            fillRoomcombo();
        }

        public void updateroomondelete()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string newstate = "free";
            int roomid = Convert.ToInt32(ResGridView.SelectedRows[0].Cells[2].Value.ToString());

            string Myquery = "Update Room_tbl set RoomFree ='" + newstate + "'where RoomId = '" + roomid  + "'; ";
            SqlCommand cmd = new SqlCommand(Myquery, con);
            cmd.ExecuteNonQuery();
            //MessageBox.Show("Reservation  Successfully Edited");
            con.Close();

            fillRoomcombo();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if(ResId.Text=="")
            {
                MessageBox.Show("Empty ResId, Enter the Reservation Id");
            }
            else
            {
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

                con.Open();
                string Myquery = "Update Reservation_tbl set Client ='" + clientncb.SelectedValue.ToString() + "',Room='" + roomicb.SelectedValue.ToString() + "', DateIn = '" + dateTimein.Value.ToString() + "', DateOut = '" + dateTimeOut.Value.ToString() + "' where ResId = '" + ResId.Text + "'; ";
                SqlCommand cmd = new SqlCommand(Myquery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Reservation  Successfully Edited");
                con.Close();
                populate();
            }
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ResGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ResId.Text = ResGridView.SelectedRows[0].Cells[0].Value.ToString();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (ResId.Text == "")
            {
                MessageBox.Show("Enter the Reservation to be deleted");
            }
            else
            {


                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

                con.Open();
                string query = "delete from Reservation_tbl where ResId ='" + ResId.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Reservation Deleted Successfully");
                con.Close();
                updateroomondelete();
                populate();
            }
        }

        private void ReservationSearchlbl_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string myquery = "select * from Reservation_tbl where ResId='" + ReservationSearchlbl.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ResGridView.DataSource = ds.Tables[0];

            con.Close();

        }

        private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDate.Text = DateTime.Now.ToLongTimeString();

        }

        private void roomicb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void clintButton2_Click(object sender, EventArgs e)
        {
            ClientInfo ci = new ClientInfo();
            ci.Show();
            this.Hide();
        }

        private void staffButton3_Click(object sender, EventArgs e)
        {
            StaffInfo si = new StaffInfo();
            si.Show();
            this.Hide();
        }

        private void roomButton5_Click(object sender, EventArgs e)
        {
            RoomInfo ri = new RoomInfo();
            ri.Show();
            this.Hide();
        }

        private void reservation2Button4_Click(object sender, EventArgs e)
        {
            ReservationInfo ri = new ReservationInfo();
            ri.Show();
            this.Hide();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
