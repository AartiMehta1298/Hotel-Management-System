﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace AK_Hotel_Management_System
{
    public partial class RoomInfo : Form
    {
        public void populate()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string myquery = "select * from Room_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            RoomGridView.DataSource = ds.Tables[0];

            con.Close();
        }

        public RoomInfo()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            string isfree;
            if(yesradio.Checked == true)
                {
                    isfree = "free";
                }
                else
                {
                    isfree = "busy";

                }
                con.Open();
            SqlCommand cmd = new SqlCommand("insert into Room_tbl values('" + RoomIdlbl.Text + "','" + RoomPhnlbl.Text + "','" + isfree + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Room Added Successfully");
            con.Close();
            populate();
        }

       
        private void btnEdit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            string isfree;
            if (yesradio.Checked == true)
            {
                isfree = "free";
            }
            else
            {
                isfree = "busy";

            }
            con.Open();
            string Myquery = "Update Room_tbl set RoomPhone='" + RoomPhnlbl.Text + "',RoomFree='" + isfree + "' where RoomId='" + RoomIdlbl.Text + "';";
            SqlCommand cmd = new SqlCommand(Myquery, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Room  Successfully Edited");
            con.Close();
            populate();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string query = "delete from Room_tbl where RoomId ='" + RoomIdlbl.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Room Deleted Successfully");
            con.Close();
            populate();
        }

        private void RoomInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'akhotelDataSet2.Room_tbl' table. You can move, or remove it, as needed.
            this.room_tblTableAdapter.Fill(this.akhotelDataSet2.Room_tbl);
            timer1.Start();


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDate.Text = DateTime.Now.ToLongTimeString();

        }

        private void RoomGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RoomIdlbl.Text = RoomGridView.SelectedRows[0].Cells[0].Value.ToString();
            RoomPhnlbl.Text = RoomGridView.SelectedRows[0].Cells[1].Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string myquery = "select * from Room_tbl where RoomId='" + RoomSearch.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            RoomGridView.DataSource = ds.Tables[0];

            con.Close();
        }

        private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
        {
            populate();

        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void RoomSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void clintButton2_Click(object sender, EventArgs e)
        {
            ClientInfo ci = new ClientInfo();
            ci.Show();
            this.Hide();
        }

        private void staffButton3_Click(object sender, EventArgs e)
        {
            StaffInfo si = new StaffInfo();
            si.Show();
            this.Hide();

        }

        private void roomButton5_Click(object sender, EventArgs e)
        {
            RoomInfo ri = new RoomInfo();
            ri.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void reservation2Button4_Click(object sender, EventArgs e)
        {
            ReservationInfo ri = new ReservationInfo();
            ri.Show();
            this.Hide();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
