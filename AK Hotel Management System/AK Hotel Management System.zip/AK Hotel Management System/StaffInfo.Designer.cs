﻿
namespace AK_Hotel_Management_System
{
    partial class StaffInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffInfo));
            this.StaffNamelbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.StaffGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.staffIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffPasswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stafftblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.akhotelDataSet1 = new AK_Hotel_Management_System.akhotelDataSet1();
            this.StaffSearch = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.btnEdit = new Guna.UI2.WinForms.Guna2Button();
            this.btnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.StaffGenlbl = new Guna.UI2.WinForms.Guna2ComboBox();
            this.StaffPhonelbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.StaffIdlbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.staff_tblTableAdapter = new AK_Hotel_Management_System.akhotelDataSet1TableAdapters.Staff_tblTableAdapter();
            this.Passwordlbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.roomButton5 = new Guna.UI2.WinForms.Guna2Button();
            this.reservation2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.staffButton3 = new Guna.UI2.WinForms.Guna2Button();
            this.clintButton2 = new Guna.UI2.WinForms.Guna2Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.StaffGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stafftblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.akhotelDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // StaffNamelbl
            // 
            this.StaffNamelbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StaffNamelbl.DefaultText = "";
            this.StaffNamelbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.StaffNamelbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.StaffNamelbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffNamelbl.DisabledState.Parent = this.StaffNamelbl;
            this.StaffNamelbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffNamelbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffNamelbl.FocusedState.Parent = this.StaffNamelbl;
            this.StaffNamelbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffNamelbl.HoverState.Parent = this.StaffNamelbl;
            this.StaffNamelbl.Location = new System.Drawing.Point(313, 218);
            this.StaffNamelbl.Margin = new System.Windows.Forms.Padding(6);
            this.StaffNamelbl.Name = "StaffNamelbl";
            this.StaffNamelbl.PasswordChar = '\0';
            this.StaffNamelbl.PlaceholderText = "StaffName";
            this.StaffNamelbl.SelectedText = "";
            this.StaffNamelbl.ShadowDecoration.Parent = this.StaffNamelbl;
            this.StaffNamelbl.Size = new System.Drawing.Size(245, 33);
            this.StaffNamelbl.TabIndex = 16;
            this.StaffNamelbl.TextChanged += new System.EventHandler(this.ClientNamelbl_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(931, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 36);
            this.button1.TabIndex = 24;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // StaffGridView
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.StaffGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.StaffGridView.AutoGenerateColumns = false;
            this.StaffGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.StaffGridView.BackgroundColor = System.Drawing.Color.White;
            this.StaffGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.StaffGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.StaffGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(211)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.StaffGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.StaffGridView.ColumnHeadersHeight = 21;
            this.StaffGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.staffIdDataGridViewTextBoxColumn,
            this.staffNameDataGridViewTextBoxColumn,
            this.staffPhoneDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.staffPasswordDataGridViewTextBoxColumn});
            this.StaffGridView.DataSource = this.stafftblBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(241)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(210)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.StaffGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.StaffGridView.EnableHeadersVisualStyles = false;
            this.StaffGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.StaffGridView.Location = new System.Drawing.Point(591, 130);
            this.StaffGridView.Name = "StaffGridView";
            this.StaffGridView.RowHeadersVisible = false;
            this.StaffGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.StaffGridView.Size = new System.Drawing.Size(500, 264);
            this.StaffGridView.TabIndex = 23;
            this.StaffGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Cyan;
            this.StaffGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.StaffGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.StaffGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.StaffGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.StaffGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.StaffGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.StaffGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.StaffGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(211)))));
            this.StaffGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.StaffGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.StaffGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.StaffGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.StaffGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.StaffGridView.ThemeStyle.ReadOnly = false;
            this.StaffGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(241)))), ((int)(((byte)(245)))));
            this.StaffGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.StaffGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.StaffGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.StaffGridView.ThemeStyle.RowsStyle.Height = 22;
            this.StaffGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(210)))), ((int)(((byte)(225)))));
            this.StaffGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.StaffGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StaffGridView_CellContentClick);
            // 
            // staffIdDataGridViewTextBoxColumn
            // 
            this.staffIdDataGridViewTextBoxColumn.DataPropertyName = "StaffId";
            this.staffIdDataGridViewTextBoxColumn.HeaderText = "StaffId";
            this.staffIdDataGridViewTextBoxColumn.Name = "staffIdDataGridViewTextBoxColumn";
            // 
            // staffNameDataGridViewTextBoxColumn
            // 
            this.staffNameDataGridViewTextBoxColumn.DataPropertyName = "StaffName";
            this.staffNameDataGridViewTextBoxColumn.HeaderText = "StaffName";
            this.staffNameDataGridViewTextBoxColumn.Name = "staffNameDataGridViewTextBoxColumn";
            // 
            // staffPhoneDataGridViewTextBoxColumn
            // 
            this.staffPhoneDataGridViewTextBoxColumn.DataPropertyName = "StaffPhone";
            this.staffPhoneDataGridViewTextBoxColumn.HeaderText = "StaffPhone";
            this.staffPhoneDataGridViewTextBoxColumn.Name = "staffPhoneDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // staffPasswordDataGridViewTextBoxColumn
            // 
            this.staffPasswordDataGridViewTextBoxColumn.DataPropertyName = "StaffPassword";
            this.staffPasswordDataGridViewTextBoxColumn.HeaderText = "StaffPassword";
            this.staffPasswordDataGridViewTextBoxColumn.Name = "staffPasswordDataGridViewTextBoxColumn";
            // 
            // stafftblBindingSource
            // 
            this.stafftblBindingSource.DataMember = "Staff_tbl";
            this.stafftblBindingSource.DataSource = this.akhotelDataSet1;
            // 
            // akhotelDataSet1
            // 
            this.akhotelDataSet1.DataSetName = "akhotelDataSet1";
            this.akhotelDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // StaffSearch
            // 
            this.StaffSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StaffSearch.DefaultText = "";
            this.StaffSearch.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.StaffSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.StaffSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffSearch.DisabledState.Parent = this.StaffSearch;
            this.StaffSearch.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffSearch.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffSearch.FocusedState.Parent = this.StaffSearch;
            this.StaffSearch.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffSearch.HoverState.Parent = this.StaffSearch;
            this.StaffSearch.Location = new System.Drawing.Point(725, 84);
            this.StaffSearch.Name = "StaffSearch";
            this.StaffSearch.PasswordChar = '\0';
            this.StaffSearch.PlaceholderText = "StaffSearch";
            this.StaffSearch.SelectedText = "";
            this.StaffSearch.ShadowDecoration.Parent = this.StaffSearch;
            this.StaffSearch.Size = new System.Drawing.Size(200, 36);
            this.StaffSearch.TabIndex = 22;
            // 
            // btnDelete
            // 
            this.btnDelete.CheckedState.Parent = this.btnDelete;
            this.btnDelete.CustomImages.Parent = this.btnDelete;
            this.btnDelete.FillColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.HoverState.Parent = this.btnDelete;
            this.btnDelete.Location = new System.Drawing.Point(831, 400);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ShadowDecoration.Parent = this.btnDelete;
            this.btnDelete.Size = new System.Drawing.Size(114, 34);
            this.btnDelete.TabIndex = 21;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.CheckedState.Parent = this.btnEdit;
            this.btnEdit.CustomImages.Parent = this.btnEdit;
            this.btnEdit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.HoverState.Parent = this.btnEdit;
            this.btnEdit.Location = new System.Drawing.Point(711, 400);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.ShadowDecoration.Parent = this.btnEdit;
            this.btnEdit.Size = new System.Drawing.Size(114, 34);
            this.btnEdit.TabIndex = 20;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.CheckedState.Parent = this.btnAdd;
            this.btnAdd.CustomImages.Parent = this.btnAdd;
            this.btnAdd.FillColor = System.Drawing.Color.Teal;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.HoverState.Parent = this.btnAdd;
            this.btnAdd.Location = new System.Drawing.Point(591, 400);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.ShadowDecoration.Parent = this.btnAdd;
            this.btnAdd.Size = new System.Drawing.Size(114, 34);
            this.btnAdd.TabIndex = 19;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // StaffGenlbl
            // 
            this.StaffGenlbl.BackColor = System.Drawing.Color.Transparent;
            this.StaffGenlbl.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.StaffGenlbl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StaffGenlbl.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffGenlbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffGenlbl.FocusedState.Parent = this.StaffGenlbl;
            this.StaffGenlbl.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.StaffGenlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.StaffGenlbl.HoverState.Parent = this.StaffGenlbl;
            this.StaffGenlbl.ItemHeight = 30;
            this.StaffGenlbl.Items.AddRange(new object[] {
            "Male ",
            "Female",
            "Other"});
            this.StaffGenlbl.ItemsAppearance.Parent = this.StaffGenlbl;
            this.StaffGenlbl.Location = new System.Drawing.Point(316, 358);
            this.StaffGenlbl.Name = "StaffGenlbl";
            this.StaffGenlbl.ShadowDecoration.Parent = this.StaffGenlbl;
            this.StaffGenlbl.Size = new System.Drawing.Size(242, 36);
            this.StaffGenlbl.TabIndex = 18;
            // 
            // StaffPhonelbl
            // 
            this.StaffPhonelbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StaffPhonelbl.DefaultText = "";
            this.StaffPhonelbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.StaffPhonelbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.StaffPhonelbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffPhonelbl.DisabledState.Parent = this.StaffPhonelbl;
            this.StaffPhonelbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffPhonelbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffPhonelbl.FocusedState.Parent = this.StaffPhonelbl;
            this.StaffPhonelbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffPhonelbl.HoverState.Parent = this.StaffPhonelbl;
            this.StaffPhonelbl.Location = new System.Drawing.Point(313, 265);
            this.StaffPhonelbl.Margin = new System.Windows.Forms.Padding(6);
            this.StaffPhonelbl.Name = "StaffPhonelbl";
            this.StaffPhonelbl.PasswordChar = '\0';
            this.StaffPhonelbl.PlaceholderText = "Phone Number";
            this.StaffPhonelbl.SelectedText = "";
            this.StaffPhonelbl.ShadowDecoration.Parent = this.StaffPhonelbl;
            this.StaffPhonelbl.Size = new System.Drawing.Size(245, 33);
            this.StaffPhonelbl.TabIndex = 17;
            // 
            // StaffIdlbl
            // 
            this.StaffIdlbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StaffIdlbl.DefaultText = "";
            this.StaffIdlbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.StaffIdlbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.StaffIdlbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffIdlbl.DisabledState.Parent = this.StaffIdlbl;
            this.StaffIdlbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.StaffIdlbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffIdlbl.FocusedState.Parent = this.StaffIdlbl;
            this.StaffIdlbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.StaffIdlbl.HoverState.Parent = this.StaffIdlbl;
            this.StaffIdlbl.Location = new System.Drawing.Point(313, 171);
            this.StaffIdlbl.Margin = new System.Windows.Forms.Padding(6);
            this.StaffIdlbl.Name = "StaffIdlbl";
            this.StaffIdlbl.PasswordChar = '\0';
            this.StaffIdlbl.PlaceholderText = "StaffId";
            this.StaffIdlbl.SelectedText = "";
            this.StaffIdlbl.ShadowDecoration.Parent = this.StaffIdlbl;
            this.StaffIdlbl.Size = new System.Drawing.Size(242, 35);
            this.StaffIdlbl.TabIndex = 15;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(10, 57);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(37, 15);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "Date";
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(1012, 84);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(46, 35);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 26;
            this.guna2CirclePictureBox1.TabStop = false;
            this.guna2CirclePictureBox1.Click += new System.EventHandler(this.guna2CirclePictureBox1_Click);
            // 
            // staff_tblTableAdapter
            // 
            this.staff_tblTableAdapter.ClearBeforeFill = true;
            // 
            // Passwordlbl
            // 
            this.Passwordlbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Passwordlbl.DefaultText = "";
            this.Passwordlbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Passwordlbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Passwordlbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Passwordlbl.DisabledState.Parent = this.Passwordlbl;
            this.Passwordlbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Passwordlbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Passwordlbl.FocusedState.Parent = this.Passwordlbl;
            this.Passwordlbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Passwordlbl.HoverState.Parent = this.Passwordlbl;
            this.Passwordlbl.Location = new System.Drawing.Point(314, 310);
            this.Passwordlbl.Margin = new System.Windows.Forms.Padding(6);
            this.Passwordlbl.Name = "Passwordlbl";
            this.Passwordlbl.PasswordChar = '\0';
            this.Passwordlbl.PlaceholderText = "Password";
            this.Passwordlbl.SelectedText = "";
            this.Passwordlbl.ShadowDecoration.Parent = this.Passwordlbl;
            this.Passwordlbl.Size = new System.Drawing.Size(245, 33);
            this.Passwordlbl.TabIndex = 27;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.roomButton5);
            this.panel2.Controls.Add(this.reservation2Button4);
            this.panel2.Controls.Add(this.staffButton3);
            this.panel2.Controls.Add(this.clintButton2);
            this.panel2.Location = new System.Drawing.Point(2, 78);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(248, 438);
            this.panel2.TabIndex = 48;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // roomButton5
            // 
            this.roomButton5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roomButton5.BackgroundImage")));
            this.roomButton5.BorderRadius = 20;
            this.roomButton5.BorderThickness = 1;
            this.roomButton5.CheckedState.Parent = this.roomButton5;
            this.roomButton5.CustomImages.Parent = this.roomButton5;
            this.roomButton5.FillColor = System.Drawing.Color.White;
            this.roomButton5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.roomButton5.ForeColor = System.Drawing.Color.Teal;
            this.roomButton5.HoverState.Parent = this.roomButton5;
            this.roomButton5.Location = new System.Drawing.Point(45, 178);
            this.roomButton5.Name = "roomButton5";
            this.roomButton5.ShadowDecoration.Parent = this.roomButton5;
            this.roomButton5.Size = new System.Drawing.Size(169, 37);
            this.roomButton5.TabIndex = 3;
            this.roomButton5.Text = "Room";
            this.roomButton5.Click += new System.EventHandler(this.roomButton5_Click);
            // 
            // reservation2Button4
            // 
            this.reservation2Button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("reservation2Button4.BackgroundImage")));
            this.reservation2Button4.BorderRadius = 20;
            this.reservation2Button4.BorderThickness = 1;
            this.reservation2Button4.CheckedState.Parent = this.reservation2Button4;
            this.reservation2Button4.CustomImages.Parent = this.reservation2Button4;
            this.reservation2Button4.FillColor = System.Drawing.Color.White;
            this.reservation2Button4.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.reservation2Button4.ForeColor = System.Drawing.Color.Teal;
            this.reservation2Button4.HoverState.Parent = this.reservation2Button4;
            this.reservation2Button4.Location = new System.Drawing.Point(45, 250);
            this.reservation2Button4.Name = "reservation2Button4";
            this.reservation2Button4.ShadowDecoration.Parent = this.reservation2Button4;
            this.reservation2Button4.Size = new System.Drawing.Size(169, 37);
            this.reservation2Button4.TabIndex = 2;
            this.reservation2Button4.Text = "Reservation";
            this.reservation2Button4.Click += new System.EventHandler(this.reservation2Button4_Click);
            // 
            // staffButton3
            // 
            this.staffButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("staffButton3.BackgroundImage")));
            this.staffButton3.BorderRadius = 20;
            this.staffButton3.BorderThickness = 1;
            this.staffButton3.CheckedState.Parent = this.staffButton3;
            this.staffButton3.CustomImages.Parent = this.staffButton3;
            this.staffButton3.FillColor = System.Drawing.Color.White;
            this.staffButton3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.staffButton3.ForeColor = System.Drawing.Color.Teal;
            this.staffButton3.HoverState.Parent = this.staffButton3;
            this.staffButton3.Location = new System.Drawing.Point(45, 109);
            this.staffButton3.Name = "staffButton3";
            this.staffButton3.ShadowDecoration.Parent = this.staffButton3;
            this.staffButton3.Size = new System.Drawing.Size(169, 37);
            this.staffButton3.TabIndex = 1;
            this.staffButton3.Text = "Staff";
            this.staffButton3.Click += new System.EventHandler(this.staffButton3_Click);
            // 
            // clintButton2
            // 
            this.clintButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clintButton2.BackgroundImage")));
            this.clintButton2.BorderRadius = 20;
            this.clintButton2.BorderThickness = 1;
            this.clintButton2.CheckedState.Parent = this.clintButton2;
            this.clintButton2.CustomImages.Parent = this.clintButton2;
            this.clintButton2.FillColor = System.Drawing.Color.White;
            this.clintButton2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.clintButton2.ForeColor = System.Drawing.Color.Teal;
            this.clintButton2.HoverState.Parent = this.clintButton2;
            this.clintButton2.Location = new System.Drawing.Point(45, 42);
            this.clintButton2.Name = "clintButton2";
            this.clintButton2.ShadowDecoration.Parent = this.clintButton2;
            this.clintButton2.Size = new System.Drawing.Size(169, 37);
            this.clintButton2.TabIndex = 0;
            this.clintButton2.Text = "Client";
            this.clintButton2.Click += new System.EventHandler(this.clintButton2_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.lblDate);
            this.panel3.Controls.Add(this.guna2HtmlLabel1);
            this.panel3.Controls.Add(this.guna2Button1);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(2, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1073, 75);
            this.panel3.TabIndex = 47;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Sitka Display", 27F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(11, 5);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(468, 54);
            this.guna2HtmlLabel1.TabIndex = 9;
            this.guna2HtmlLabel1.Text = "AK Hotel Management System ";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("guna2Button1.BackgroundImage")));
            this.guna2Button1.BorderRadius = 17;
            this.guna2Button1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.White;
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(962, 35);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(81, 37);
            this.guna2Button1.TabIndex = 7;
            this.guna2Button1.Text = "Logout";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1046, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "x";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MediumTurquoise;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(250, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(300, 45);
            this.label2.TabIndex = 11;
            this.label2.Text = "Staff Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(250, 433);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = "Copyright @ 2021. All rights reserved  C# My Design";
            // 
            // StaffInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 485);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Passwordlbl);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.guna2CirclePictureBox1);
            this.Controls.Add(this.StaffNamelbl);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.StaffGridView);
            this.Controls.Add(this.StaffSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.StaffGenlbl);
            this.Controls.Add(this.StaffPhonelbl);
            this.Controls.Add(this.StaffIdlbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StaffInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StaffInfo";
            this.Load += new System.EventHandler(this.StaffInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StaffGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stafftblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.akhotelDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox StaffNamelbl;
        private System.Windows.Forms.Button button1;
        private Guna.UI2.WinForms.Guna2DataGridView StaffGridView;
        private Guna.UI2.WinForms.Guna2TextBox StaffSearch;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Button btnEdit;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2ComboBox StaffGenlbl;
        private Guna.UI2.WinForms.Guna2TextBox StaffPhonelbl;
        private Guna.UI2.WinForms.Guna2TextBox StaffIdlbl;
        private System.Windows.Forms.Label lblDate;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private akhotelDataSet1 akhotelDataSet1;
        private System.Windows.Forms.BindingSource stafftblBindingSource;
        private akhotelDataSet1TableAdapters.Staff_tblTableAdapter staff_tblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffPasswordDataGridViewTextBoxColumn;
        private Guna.UI2.WinForms.Guna2TextBox Passwordlbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button roomButton5;
        private Guna.UI2.WinForms.Guna2Button reservation2Button4;
        private Guna.UI2.WinForms.Guna2Button staffButton3;
        private Guna.UI2.WinForms.Guna2Button clintButton2;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}