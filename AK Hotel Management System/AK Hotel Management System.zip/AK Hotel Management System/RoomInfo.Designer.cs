﻿
namespace AK_Hotel_Management_System
{
    partial class RoomInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RoomInfo));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblDate = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.RoomPhnlbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.RoomGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.roomIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomFreeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomtblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.akhotelDataSet2 = new AK_Hotel_Management_System.akhotelDataSet2();
            this.RoomSearch = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.btnEdit = new Guna.UI2.WinForms.Guna2Button();
            this.btnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.RoomIdlbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.yesradio = new System.Windows.Forms.RadioButton();
            this.noradio = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.room_tblTableAdapter = new AK_Hotel_Management_System.akhotelDataSet2TableAdapters.Room_tblTableAdapter();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.roomButton5 = new Guna.UI2.WinForms.Guna2Button();
            this.reservation2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.staffButton3 = new Guna.UI2.WinForms.Guna2Button();
            this.clintButton2 = new Guna.UI2.WinForms.Guna2Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RoomGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomtblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.akhotelDataSet2)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(19, 57);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(37, 15);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "Date";
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(994, 89);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(46, 35);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 36;
            this.guna2CirclePictureBox1.TabStop = false;
            this.guna2CirclePictureBox1.Click += new System.EventHandler(this.guna2CirclePictureBox1_Click);
            // 
            // RoomPhnlbl
            // 
            this.RoomPhnlbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RoomPhnlbl.DefaultText = "";
            this.RoomPhnlbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.RoomPhnlbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.RoomPhnlbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RoomPhnlbl.DisabledState.Parent = this.RoomPhnlbl;
            this.RoomPhnlbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RoomPhnlbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RoomPhnlbl.FocusedState.Parent = this.RoomPhnlbl;
            this.RoomPhnlbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RoomPhnlbl.HoverState.Parent = this.RoomPhnlbl;
            this.RoomPhnlbl.Location = new System.Drawing.Point(293, 215);
            this.RoomPhnlbl.Margin = new System.Windows.Forms.Padding(6);
            this.RoomPhnlbl.Name = "RoomPhnlbl";
            this.RoomPhnlbl.PasswordChar = '\0';
            this.RoomPhnlbl.PlaceholderText = "RoomPhone";
            this.RoomPhnlbl.SelectedText = "";
            this.RoomPhnlbl.ShadowDecoration.Parent = this.RoomPhnlbl;
            this.RoomPhnlbl.Size = new System.Drawing.Size(245, 33);
            this.RoomPhnlbl.TabIndex = 29;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(913, 87);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 36);
            this.button1.TabIndex = 35;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RoomGridView
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.RoomGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.RoomGridView.AutoGenerateColumns = false;
            this.RoomGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.RoomGridView.BackgroundColor = System.Drawing.Color.White;
            this.RoomGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RoomGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.RoomGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(211)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RoomGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.RoomGridView.ColumnHeadersHeight = 21;
            this.RoomGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.roomIdDataGridViewTextBoxColumn,
            this.roomPhoneDataGridViewTextBoxColumn,
            this.roomFreeDataGridViewTextBoxColumn});
            this.RoomGridView.DataSource = this.roomtblBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(241)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(210)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.RoomGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.RoomGridView.EnableHeadersVisualStyles = false;
            this.RoomGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.RoomGridView.Location = new System.Drawing.Point(596, 130);
            this.RoomGridView.Name = "RoomGridView";
            this.RoomGridView.RowHeadersVisible = false;
            this.RoomGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.RoomGridView.Size = new System.Drawing.Size(484, 305);
            this.RoomGridView.TabIndex = 34;
            this.RoomGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Cyan;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.RoomGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.RoomGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.RoomGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(211)))));
            this.RoomGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.RoomGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.RoomGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.RoomGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.RoomGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.RoomGridView.ThemeStyle.ReadOnly = false;
            this.RoomGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(241)))), ((int)(((byte)(245)))));
            this.RoomGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.RoomGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.RoomGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.RoomGridView.ThemeStyle.RowsStyle.Height = 22;
            this.RoomGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(210)))), ((int)(((byte)(225)))));
            this.RoomGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.RoomGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RoomGridView_CellContentClick);
            // 
            // roomIdDataGridViewTextBoxColumn
            // 
            this.roomIdDataGridViewTextBoxColumn.DataPropertyName = "RoomId";
            this.roomIdDataGridViewTextBoxColumn.HeaderText = "RoomId";
            this.roomIdDataGridViewTextBoxColumn.Name = "roomIdDataGridViewTextBoxColumn";
            // 
            // roomPhoneDataGridViewTextBoxColumn
            // 
            this.roomPhoneDataGridViewTextBoxColumn.DataPropertyName = "RoomPhone";
            this.roomPhoneDataGridViewTextBoxColumn.HeaderText = "RoomPhone";
            this.roomPhoneDataGridViewTextBoxColumn.Name = "roomPhoneDataGridViewTextBoxColumn";
            // 
            // roomFreeDataGridViewTextBoxColumn
            // 
            this.roomFreeDataGridViewTextBoxColumn.DataPropertyName = "RoomFree";
            this.roomFreeDataGridViewTextBoxColumn.HeaderText = "RoomFree";
            this.roomFreeDataGridViewTextBoxColumn.Name = "roomFreeDataGridViewTextBoxColumn";
            // 
            // roomtblBindingSource
            // 
            this.roomtblBindingSource.DataMember = "Room_tbl";
            this.roomtblBindingSource.DataSource = this.akhotelDataSet2;
            // 
            // akhotelDataSet2
            // 
            this.akhotelDataSet2.DataSetName = "akhotelDataSet2";
            this.akhotelDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // RoomSearch
            // 
            this.RoomSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RoomSearch.DefaultText = "";
            this.RoomSearch.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.RoomSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.RoomSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RoomSearch.DisabledState.Parent = this.RoomSearch;
            this.RoomSearch.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RoomSearch.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RoomSearch.FocusedState.Parent = this.RoomSearch;
            this.RoomSearch.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RoomSearch.HoverState.Parent = this.RoomSearch;
            this.RoomSearch.Location = new System.Drawing.Point(710, 87);
            this.RoomSearch.Name = "RoomSearch";
            this.RoomSearch.PasswordChar = '\0';
            this.RoomSearch.PlaceholderText = "RoomSearch";
            this.RoomSearch.SelectedText = "";
            this.RoomSearch.ShadowDecoration.Parent = this.RoomSearch;
            this.RoomSearch.Size = new System.Drawing.Size(200, 36);
            this.RoomSearch.TabIndex = 33;
            this.RoomSearch.TextChanged += new System.EventHandler(this.RoomSearch_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.CheckedState.Parent = this.btnDelete;
            this.btnDelete.CustomImages.Parent = this.btnDelete;
            this.btnDelete.FillColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.HoverState.Parent = this.btnDelete;
            this.btnDelete.Location = new System.Drawing.Point(798, 440);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ShadowDecoration.Parent = this.btnDelete;
            this.btnDelete.Size = new System.Drawing.Size(94, 29);
            this.btnDelete.TabIndex = 32;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.CheckedState.Parent = this.btnEdit;
            this.btnEdit.CustomImages.Parent = this.btnEdit;
            this.btnEdit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.HoverState.Parent = this.btnEdit;
            this.btnEdit.Location = new System.Drawing.Point(698, 440);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.ShadowDecoration.Parent = this.btnEdit;
            this.btnEdit.Size = new System.Drawing.Size(94, 29);
            this.btnEdit.TabIndex = 31;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.CheckedState.Parent = this.btnAdd;
            this.btnAdd.CustomImages.Parent = this.btnAdd;
            this.btnAdd.FillColor = System.Drawing.Color.Teal;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.HoverState.Parent = this.btnAdd;
            this.btnAdd.Location = new System.Drawing.Point(599, 441);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.ShadowDecoration.Parent = this.btnAdd;
            this.btnAdd.Size = new System.Drawing.Size(94, 29);
            this.btnAdd.TabIndex = 30;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // RoomIdlbl
            // 
            this.RoomIdlbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RoomIdlbl.DefaultText = "";
            this.RoomIdlbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.RoomIdlbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.RoomIdlbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RoomIdlbl.DisabledState.Parent = this.RoomIdlbl;
            this.RoomIdlbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.RoomIdlbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RoomIdlbl.FocusedState.Parent = this.RoomIdlbl;
            this.RoomIdlbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.RoomIdlbl.HoverState.Parent = this.RoomIdlbl;
            this.RoomIdlbl.Location = new System.Drawing.Point(296, 168);
            this.RoomIdlbl.Margin = new System.Windows.Forms.Padding(6);
            this.RoomIdlbl.Name = "RoomIdlbl";
            this.RoomIdlbl.PasswordChar = '\0';
            this.RoomIdlbl.PlaceholderText = "RoomId";
            this.RoomIdlbl.SelectedText = "";
            this.RoomIdlbl.ShadowDecoration.Parent = this.RoomIdlbl;
            this.RoomIdlbl.Size = new System.Drawing.Size(242, 35);
            this.RoomIdlbl.TabIndex = 28;
            // 
            // yesradio
            // 
            this.yesradio.AutoSize = true;
            this.yesradio.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yesradio.ForeColor = System.Drawing.Color.Teal;
            this.yesradio.Location = new System.Drawing.Point(377, 261);
            this.yesradio.Name = "yesradio";
            this.yesradio.Size = new System.Drawing.Size(63, 28);
            this.yesradio.TabIndex = 37;
            this.yesradio.TabStop = true;
            this.yesradio.Text = "Yes";
            this.yesradio.UseVisualStyleBackColor = true;
            // 
            // noradio
            // 
            this.noradio.AutoSize = true;
            this.noradio.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noradio.ForeColor = System.Drawing.Color.Teal;
            this.noradio.Location = new System.Drawing.Point(455, 263);
            this.noradio.Name = "noradio";
            this.noradio.Size = new System.Drawing.Size(55, 28);
            this.noradio.TabIndex = 38;
            this.noradio.TabStop = true;
            this.noradio.Text = "No";
            this.noradio.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(307, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 24);
            this.label2.TabIndex = 39;
            this.label2.Text = "Free";
            // 
            // room_tblTableAdapter
            // 
            this.room_tblTableAdapter.ClearBeforeFill = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.roomButton5);
            this.panel2.Controls.Add(this.reservation2Button4);
            this.panel2.Controls.Add(this.staffButton3);
            this.panel2.Controls.Add(this.clintButton2);
            this.panel2.Location = new System.Drawing.Point(11, 72);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(248, 438);
            this.panel2.TabIndex = 52;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // roomButton5
            // 
            this.roomButton5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roomButton5.BackgroundImage")));
            this.roomButton5.BorderRadius = 20;
            this.roomButton5.BorderThickness = 1;
            this.roomButton5.CheckedState.Parent = this.roomButton5;
            this.roomButton5.CustomImages.Parent = this.roomButton5;
            this.roomButton5.FillColor = System.Drawing.Color.White;
            this.roomButton5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.roomButton5.ForeColor = System.Drawing.Color.Teal;
            this.roomButton5.HoverState.Parent = this.roomButton5;
            this.roomButton5.Location = new System.Drawing.Point(45, 178);
            this.roomButton5.Name = "roomButton5";
            this.roomButton5.ShadowDecoration.Parent = this.roomButton5;
            this.roomButton5.Size = new System.Drawing.Size(169, 37);
            this.roomButton5.TabIndex = 3;
            this.roomButton5.Text = "Room";
            this.roomButton5.Click += new System.EventHandler(this.roomButton5_Click);
            // 
            // reservation2Button4
            // 
            this.reservation2Button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("reservation2Button4.BackgroundImage")));
            this.reservation2Button4.BorderRadius = 20;
            this.reservation2Button4.BorderThickness = 1;
            this.reservation2Button4.CheckedState.Parent = this.reservation2Button4;
            this.reservation2Button4.CustomImages.Parent = this.reservation2Button4;
            this.reservation2Button4.FillColor = System.Drawing.Color.White;
            this.reservation2Button4.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.reservation2Button4.ForeColor = System.Drawing.Color.Teal;
            this.reservation2Button4.HoverState.Parent = this.reservation2Button4;
            this.reservation2Button4.Location = new System.Drawing.Point(45, 250);
            this.reservation2Button4.Name = "reservation2Button4";
            this.reservation2Button4.ShadowDecoration.Parent = this.reservation2Button4;
            this.reservation2Button4.Size = new System.Drawing.Size(169, 37);
            this.reservation2Button4.TabIndex = 2;
            this.reservation2Button4.Text = "Reservation";
            this.reservation2Button4.Click += new System.EventHandler(this.reservation2Button4_Click);
            // 
            // staffButton3
            // 
            this.staffButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("staffButton3.BackgroundImage")));
            this.staffButton3.BorderRadius = 20;
            this.staffButton3.BorderThickness = 1;
            this.staffButton3.CheckedState.Parent = this.staffButton3;
            this.staffButton3.CustomImages.Parent = this.staffButton3;
            this.staffButton3.FillColor = System.Drawing.Color.White;
            this.staffButton3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.staffButton3.ForeColor = System.Drawing.Color.Teal;
            this.staffButton3.HoverState.Parent = this.staffButton3;
            this.staffButton3.Location = new System.Drawing.Point(45, 109);
            this.staffButton3.Name = "staffButton3";
            this.staffButton3.ShadowDecoration.Parent = this.staffButton3;
            this.staffButton3.Size = new System.Drawing.Size(169, 37);
            this.staffButton3.TabIndex = 1;
            this.staffButton3.Text = "Staff";
            this.staffButton3.Click += new System.EventHandler(this.staffButton3_Click);
            // 
            // clintButton2
            // 
            this.clintButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clintButton2.BackgroundImage")));
            this.clintButton2.BorderRadius = 20;
            this.clintButton2.BorderThickness = 1;
            this.clintButton2.CheckedState.Parent = this.clintButton2;
            this.clintButton2.CustomImages.Parent = this.clintButton2;
            this.clintButton2.FillColor = System.Drawing.Color.White;
            this.clintButton2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.clintButton2.ForeColor = System.Drawing.Color.Teal;
            this.clintButton2.HoverState.Parent = this.clintButton2;
            this.clintButton2.Location = new System.Drawing.Point(45, 42);
            this.clintButton2.Name = "clintButton2";
            this.clintButton2.ShadowDecoration.Parent = this.clintButton2;
            this.clintButton2.Size = new System.Drawing.Size(169, 37);
            this.clintButton2.TabIndex = 0;
            this.clintButton2.Text = "Client";
            this.clintButton2.Click += new System.EventHandler(this.clintButton2_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.guna2HtmlLabel1);
            this.panel3.Controls.Add(this.guna2Button1);
            this.panel3.Controls.Add(this.lblDate);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(11, -3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1073, 75);
            this.panel3.TabIndex = 51;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Sitka Display", 27F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(11, 5);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(468, 54);
            this.guna2HtmlLabel1.TabIndex = 9;
            this.guna2HtmlLabel1.Text = "AK Hotel Management System ";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("guna2Button1.BackgroundImage")));
            this.guna2Button1.BorderRadius = 17;
            this.guna2Button1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.White;
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(962, 35);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(81, 37);
            this.guna2Button1.TabIndex = 7;
            this.guna2Button1.Text = "Logout";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1046, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "x";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(259, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 45);
            this.label1.TabIndex = 53;
            this.label1.Text = "Room Information";
            // 
            // RoomInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 485);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.noradio);
            this.Controls.Add(this.yesradio);
            this.Controls.Add(this.guna2CirclePictureBox1);
            this.Controls.Add(this.RoomPhnlbl);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.RoomGridView);
            this.Controls.Add(this.RoomSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.RoomIdlbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RoomInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RoomInfo";
            this.Load += new System.EventHandler(this.RoomInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RoomGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomtblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.akhotelDataSet2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblDate;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox RoomPhnlbl;
        private System.Windows.Forms.Button button1;
        private Guna.UI2.WinForms.Guna2DataGridView RoomGridView;
        private Guna.UI2.WinForms.Guna2TextBox RoomSearch;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Button btnEdit;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2TextBox RoomIdlbl;
        private System.Windows.Forms.RadioButton yesradio;
        private System.Windows.Forms.RadioButton noradio;
        private System.Windows.Forms.Label label2;
        private akhotelDataSet2 akhotelDataSet2;
        private System.Windows.Forms.BindingSource roomtblBindingSource;
        private akhotelDataSet2TableAdapters.Room_tblTableAdapter room_tblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomFreeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button roomButton5;
        private Guna.UI2.WinForms.Guna2Button reservation2Button4;
        private Guna.UI2.WinForms.Guna2Button staffButton3;
        private Guna.UI2.WinForms.Guna2Button clintButton2;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
    }
}