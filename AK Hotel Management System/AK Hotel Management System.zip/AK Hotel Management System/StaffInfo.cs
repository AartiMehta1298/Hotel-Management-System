﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AK_Hotel_Management_System
{
    public partial class StaffInfo : Form
    {
        public void populate()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string myquery = "select * from Staff_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StaffGridView.DataSource = ds.Tables[0];

            con.Close();
        }

        public StaffInfo()
        {
            InitializeComponent();
        }

        private void ClientNamelbl_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
        {
            populate();

        }

        private void StaffInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'akhotelDataSet1.Staff_tbl' table. You can move, or remove it, as needed.
            this.staff_tblTableAdapter.Fill(this.akhotelDataSet1.Staff_tbl);
            lblDate.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
           // populate();


        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Staff_tbl values('" + StaffIdlbl.Text + "','" + StaffNamelbl.Text + "','" + StaffPhonelbl.Text + "','" + StaffGenlbl.SelectedItem.ToString() + "','"+Passwordlbl.Text+"')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Staff Added Successfully");
            con.Close();
            populate();



        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string Myquery = "Update Staff_tbl set StaffName='" + StaffNamelbl.Text + "',StaffPhone='" + StaffPhonelbl.Text + "',Gender='" + StaffGenlbl.SelectedItem.ToString() +"',StaffPassword='"+ Passwordlbl.Text +"' where StaffId='"+ StaffIdlbl.Text +"';";
            SqlCommand cmd = new SqlCommand(Myquery, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Staff  Successfully Edited");
            con.Close();
            populate();


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string query = "delete from Staff_tbl where StaffId ='" + StaffIdlbl.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Staff Deleted Successfully");
            con.Close();
            populate();


        }

        private void StaffGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            StaffIdlbl.Text = StaffGridView.SelectedRows[0].Cells[0].Value.ToString();
            StaffNamelbl.Text = StaffGridView.SelectedRows[0].Cells[1].Value.ToString();
            StaffPhonelbl.Text = StaffGridView.SelectedRows[0].Cells[2].Value.ToString();
            Passwordlbl.Text = StaffGridView.SelectedRows[0].Cells[4].Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=akhotel;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            string myquery = "select * from Staff_tbl where StaffId='" + StaffSearch.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(myquery, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StaffGridView.DataSource = ds.Tables[0];

            con.Close();
            

        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDate.Text = DateTime.Now.ToLongTimeString();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void clintButton2_Click(object sender, EventArgs e)
        {
            ClientInfo ci = new ClientInfo();
            ci.Show();
            this.Hide();
        }

        private void staffButton3_Click(object sender, EventArgs e)
        {
            StaffInfo si = new StaffInfo();
            si.Show();
            this.Hide();
        }

        private void roomButton5_Click(object sender, EventArgs e)
        {
            RoomInfo ri = new RoomInfo();
            ri.Show();
            this.Hide();
        }

        private void reservation2Button4_Click(object sender, EventArgs e)
        {
            ReservationInfo ri = new ReservationInfo();
            ri.Show();
            this.Hide();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
