﻿
namespace AK_Hotel_Management_System
{
    partial class ReservationInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReservationInfo));
            this.ResGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.resIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateInDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reservationtblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.akhotelDataSet3 = new AK_Hotel_Management_System.akhotelDataSet3();
            this.button1 = new System.Windows.Forms.Button();
            this.ReservationSearchlbl = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.btnEdit = new Guna.UI2.WinForms.Guna2Button();
            this.btnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.ResId = new Guna.UI2.WinForms.Guna2TextBox();
            this.DateIn = new System.Windows.Forms.Label();
            this.DateOut = new System.Windows.Forms.Label();
            this.dateTimein = new System.Windows.Forms.DateTimePicker();
            this.dateTimeOut = new System.Windows.Forms.DateTimePicker();
            this.clientncb = new System.Windows.Forms.ComboBox();
            this.roomicb = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblDate = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.roomButton5 = new Guna.UI2.WinForms.Guna2Button();
            this.reservation2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.staffButton3 = new Guna.UI2.WinForms.Guna2Button();
            this.clintButton2 = new Guna.UI2.WinForms.Guna2Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.reservation_tblTableAdapter = new AK_Hotel_Management_System.akhotelDataSet3TableAdapters.Reservation_tblTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.ResGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationtblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.akhotelDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ResGridView
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.ResGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.ResGridView.AutoGenerateColumns = false;
            this.ResGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ResGridView.BackgroundColor = System.Drawing.Color.White;
            this.ResGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ResGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ResGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(211)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ResGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.ResGridView.ColumnHeadersHeight = 21;
            this.ResGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.resIdDataGridViewTextBoxColumn,
            this.clientDataGridViewTextBoxColumn,
            this.roomDataGridViewTextBoxColumn,
            this.dateInDataGridViewTextBoxColumn,
            this.dateOutDataGridViewTextBoxColumn});
            this.ResGridView.DataSource = this.reservationtblBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(241)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(210)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ResGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.ResGridView.EnableHeadersVisualStyles = false;
            this.ResGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.ResGridView.Location = new System.Drawing.Point(659, 123);
            this.ResGridView.Name = "ResGridView";
            this.ResGridView.RowHeadersVisible = false;
            this.ResGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ResGridView.Size = new System.Drawing.Size(413, 302);
            this.ResGridView.TabIndex = 36;
            this.ResGridView.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Cyan;
            this.ResGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.ResGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.ResGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.ResGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.ResGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.ResGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.ResGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(235)))), ((int)(((byte)(241)))));
            this.ResGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(211)))));
            this.ResGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ResGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.ResGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.ResGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.ResGridView.ThemeStyle.HeaderStyle.Height = 21;
            this.ResGridView.ThemeStyle.ReadOnly = false;
            this.ResGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(241)))), ((int)(((byte)(245)))));
            this.ResGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ResGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.ResGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.ResGridView.ThemeStyle.RowsStyle.Height = 22;
            this.ResGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(210)))), ((int)(((byte)(225)))));
            this.ResGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.ResGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ResGridView_CellContentClick);
            // 
            // resIdDataGridViewTextBoxColumn
            // 
            this.resIdDataGridViewTextBoxColumn.DataPropertyName = "ResId";
            this.resIdDataGridViewTextBoxColumn.HeaderText = "ResId";
            this.resIdDataGridViewTextBoxColumn.Name = "resIdDataGridViewTextBoxColumn";
            // 
            // clientDataGridViewTextBoxColumn
            // 
            this.clientDataGridViewTextBoxColumn.DataPropertyName = "Client";
            this.clientDataGridViewTextBoxColumn.HeaderText = "Client";
            this.clientDataGridViewTextBoxColumn.Name = "clientDataGridViewTextBoxColumn";
            // 
            // roomDataGridViewTextBoxColumn
            // 
            this.roomDataGridViewTextBoxColumn.DataPropertyName = "Room";
            this.roomDataGridViewTextBoxColumn.HeaderText = "Room";
            this.roomDataGridViewTextBoxColumn.Name = "roomDataGridViewTextBoxColumn";
            // 
            // dateInDataGridViewTextBoxColumn
            // 
            this.dateInDataGridViewTextBoxColumn.DataPropertyName = "DateIn";
            this.dateInDataGridViewTextBoxColumn.HeaderText = "DateIn";
            this.dateInDataGridViewTextBoxColumn.Name = "dateInDataGridViewTextBoxColumn";
            // 
            // dateOutDataGridViewTextBoxColumn
            // 
            this.dateOutDataGridViewTextBoxColumn.DataPropertyName = "DateOut";
            this.dateOutDataGridViewTextBoxColumn.HeaderText = "DateOut";
            this.dateOutDataGridViewTextBoxColumn.Name = "dateOutDataGridViewTextBoxColumn";
            // 
            // reservationtblBindingSource
            // 
            this.reservationtblBindingSource.DataMember = "Reservation_tbl";
            this.reservationtblBindingSource.DataSource = this.akhotelDataSet3;
            // 
            // akhotelDataSet3
            // 
            this.akhotelDataSet3.DataSetName = "akhotelDataSet3";
            this.akhotelDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(921, 82);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 36);
            this.button1.TabIndex = 37;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ReservationSearchlbl
            // 
            this.ReservationSearchlbl.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ReservationSearchlbl.DefaultText = "";
            this.ReservationSearchlbl.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ReservationSearchlbl.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ReservationSearchlbl.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ReservationSearchlbl.DisabledState.Parent = this.ReservationSearchlbl;
            this.ReservationSearchlbl.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ReservationSearchlbl.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ReservationSearchlbl.FocusedState.Parent = this.ReservationSearchlbl;
            this.ReservationSearchlbl.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ReservationSearchlbl.HoverState.Parent = this.ReservationSearchlbl;
            this.ReservationSearchlbl.Location = new System.Drawing.Point(716, 82);
            this.ReservationSearchlbl.Name = "ReservationSearchlbl";
            this.ReservationSearchlbl.PasswordChar = '\0';
            this.ReservationSearchlbl.PlaceholderText = "Reservation Search";
            this.ReservationSearchlbl.SelectedText = "";
            this.ReservationSearchlbl.ShadowDecoration.Parent = this.ReservationSearchlbl;
            this.ReservationSearchlbl.Size = new System.Drawing.Size(200, 36);
            this.ReservationSearchlbl.TabIndex = 35;
            this.ReservationSearchlbl.TextChanged += new System.EventHandler(this.ReservationSearchlbl_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.CheckedState.Parent = this.btnDelete;
            this.btnDelete.CustomImages.Parent = this.btnDelete;
            this.btnDelete.FillColor = System.Drawing.Color.Red;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.HoverState.Parent = this.btnDelete;
            this.btnDelete.Location = new System.Drawing.Point(859, 428);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ShadowDecoration.Parent = this.btnDelete;
            this.btnDelete.Size = new System.Drawing.Size(94, 29);
            this.btnDelete.TabIndex = 34;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.CheckedState.Parent = this.btnEdit;
            this.btnEdit.CustomImages.Parent = this.btnEdit;
            this.btnEdit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnEdit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.HoverState.Parent = this.btnEdit;
            this.btnEdit.Location = new System.Drawing.Point(759, 428);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.ShadowDecoration.Parent = this.btnEdit;
            this.btnEdit.Size = new System.Drawing.Size(94, 29);
            this.btnEdit.TabIndex = 33;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Teal;
            this.btnAdd.CheckedState.Parent = this.btnAdd;
            this.btnAdd.CustomImages.Parent = this.btnAdd;
            this.btnAdd.FillColor = System.Drawing.Color.Teal;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.HoverState.Parent = this.btnAdd;
            this.btnAdd.Location = new System.Drawing.Point(659, 428);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.ShadowDecoration.Parent = this.btnAdd;
            this.btnAdd.Size = new System.Drawing.Size(94, 29);
            this.btnAdd.TabIndex = 32;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(999, 82);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(46, 35);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 38;
            this.guna2CirclePictureBox1.TabStop = false;
            this.guna2CirclePictureBox1.Click += new System.EventHandler(this.guna2CirclePictureBox1_Click);
            // 
            // ResId
            // 
            this.ResId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ResId.DefaultText = "";
            this.ResId.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.ResId.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.ResId.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ResId.DisabledState.Parent = this.ResId;
            this.ResId.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.ResId.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ResId.FocusedState.Parent = this.ResId;
            this.ResId.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ResId.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.ResId.HoverState.Parent = this.ResId;
            this.ResId.Location = new System.Drawing.Point(387, 141);
            this.ResId.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.ResId.Name = "ResId";
            this.ResId.PasswordChar = '\0';
            this.ResId.PlaceholderText = "Reservation Id";
            this.ResId.SelectedText = "";
            this.ResId.ShadowDecoration.Parent = this.ResId;
            this.ResId.Size = new System.Drawing.Size(193, 47);
            this.ResId.TabIndex = 29;
            // 
            // DateIn
            // 
            this.DateIn.AutoSize = true;
            this.DateIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateIn.Location = new System.Drawing.Point(390, 313);
            this.DateIn.Name = "DateIn";
            this.DateIn.Size = new System.Drawing.Size(58, 20);
            this.DateIn.TabIndex = 39;
            this.DateIn.Text = "DateIn";
            // 
            // DateOut
            // 
            this.DateOut.AutoSize = true;
            this.DateOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateOut.Location = new System.Drawing.Point(390, 368);
            this.DateOut.Name = "DateOut";
            this.DateOut.Size = new System.Drawing.Size(70, 20);
            this.DateOut.TabIndex = 40;
            this.DateOut.Text = "DateOut";
            // 
            // dateTimein
            // 
            this.dateTimein.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dateTimein.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimein.Location = new System.Drawing.Point(476, 313);
            this.dateTimein.Name = "dateTimein";
            this.dateTimein.Size = new System.Drawing.Size(145, 26);
            this.dateTimein.TabIndex = 41;
            this.dateTimein.ValueChanged += new System.EventHandler(this.dateTimein_ValueChanged);
            // 
            // dateTimeOut
            // 
            this.dateTimeOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeOut.Location = new System.Drawing.Point(478, 368);
            this.dateTimeOut.Name = "dateTimeOut";
            this.dateTimeOut.Size = new System.Drawing.Size(143, 26);
            this.dateTimeOut.TabIndex = 42;
            this.dateTimeOut.ValueChanged += new System.EventHandler(this.dateTimeOut_ValueChanged);
            // 
            // clientncb
            // 
            this.clientncb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientncb.FormattingEnabled = true;
            this.clientncb.Location = new System.Drawing.Point(476, 206);
            this.clientncb.Name = "clientncb";
            this.clientncb.Size = new System.Drawing.Size(106, 28);
            this.clientncb.TabIndex = 43;
            this.clientncb.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // roomicb
            // 
            this.roomicb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomicb.FormattingEnabled = true;
            this.roomicb.Location = new System.Drawing.Point(476, 258);
            this.roomicb.Name = "roomicb";
            this.roomicb.Size = new System.Drawing.Size(106, 28);
            this.roomicb.TabIndex = 44;
            this.roomicb.SelectedIndexChanged += new System.EventHandler(this.roomicb_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(390, 214);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 45;
            this.label2.Text = "Client";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(389, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 20);
            this.label3.TabIndex = 46;
            this.label3.Text = "Room";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(18, 55);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(37, 15);
            this.lblDate.TabIndex = 47;
            this.lblDate.Text = "Date";
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.roomButton5);
            this.panel2.Controls.Add(this.reservation2Button4);
            this.panel2.Controls.Add(this.staffButton3);
            this.panel2.Controls.Add(this.clintButton2);
            this.panel2.Location = new System.Drawing.Point(3, 74);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(248, 438);
            this.panel2.TabIndex = 50;
            // 
            // roomButton5
            // 
            this.roomButton5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("roomButton5.BackgroundImage")));
            this.roomButton5.BorderRadius = 20;
            this.roomButton5.BorderThickness = 1;
            this.roomButton5.CheckedState.Parent = this.roomButton5;
            this.roomButton5.CustomImages.Parent = this.roomButton5;
            this.roomButton5.FillColor = System.Drawing.Color.White;
            this.roomButton5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.roomButton5.ForeColor = System.Drawing.Color.Teal;
            this.roomButton5.HoverState.Parent = this.roomButton5;
            this.roomButton5.Location = new System.Drawing.Point(45, 178);
            this.roomButton5.Name = "roomButton5";
            this.roomButton5.ShadowDecoration.Parent = this.roomButton5;
            this.roomButton5.Size = new System.Drawing.Size(169, 37);
            this.roomButton5.TabIndex = 3;
            this.roomButton5.Text = "Room";
            this.roomButton5.Click += new System.EventHandler(this.roomButton5_Click);
            // 
            // reservation2Button4
            // 
            this.reservation2Button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("reservation2Button4.BackgroundImage")));
            this.reservation2Button4.BorderRadius = 20;
            this.reservation2Button4.BorderThickness = 1;
            this.reservation2Button4.CheckedState.Parent = this.reservation2Button4;
            this.reservation2Button4.CustomImages.Parent = this.reservation2Button4;
            this.reservation2Button4.FillColor = System.Drawing.Color.White;
            this.reservation2Button4.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.reservation2Button4.ForeColor = System.Drawing.Color.Teal;
            this.reservation2Button4.HoverState.Parent = this.reservation2Button4;
            this.reservation2Button4.Location = new System.Drawing.Point(45, 250);
            this.reservation2Button4.Name = "reservation2Button4";
            this.reservation2Button4.ShadowDecoration.Parent = this.reservation2Button4;
            this.reservation2Button4.Size = new System.Drawing.Size(169, 37);
            this.reservation2Button4.TabIndex = 2;
            this.reservation2Button4.Text = "Reservation";
            this.reservation2Button4.Click += new System.EventHandler(this.reservation2Button4_Click);
            // 
            // staffButton3
            // 
            this.staffButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("staffButton3.BackgroundImage")));
            this.staffButton3.BorderRadius = 20;
            this.staffButton3.BorderThickness = 1;
            this.staffButton3.CheckedState.Parent = this.staffButton3;
            this.staffButton3.CustomImages.Parent = this.staffButton3;
            this.staffButton3.FillColor = System.Drawing.Color.White;
            this.staffButton3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.staffButton3.ForeColor = System.Drawing.Color.Teal;
            this.staffButton3.HoverState.Parent = this.staffButton3;
            this.staffButton3.Location = new System.Drawing.Point(45, 109);
            this.staffButton3.Name = "staffButton3";
            this.staffButton3.ShadowDecoration.Parent = this.staffButton3;
            this.staffButton3.Size = new System.Drawing.Size(169, 37);
            this.staffButton3.TabIndex = 1;
            this.staffButton3.Text = "Staff";
            this.staffButton3.Click += new System.EventHandler(this.staffButton3_Click);
            // 
            // clintButton2
            // 
            this.clintButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clintButton2.BackgroundImage")));
            this.clintButton2.BorderRadius = 20;
            this.clintButton2.BorderThickness = 1;
            this.clintButton2.CheckedState.Parent = this.clintButton2;
            this.clintButton2.CustomImages.Parent = this.clintButton2;
            this.clintButton2.FillColor = System.Drawing.Color.White;
            this.clintButton2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold);
            this.clintButton2.ForeColor = System.Drawing.Color.Teal;
            this.clintButton2.HoverState.Parent = this.clintButton2;
            this.clintButton2.Location = new System.Drawing.Point(45, 42);
            this.clintButton2.Name = "clintButton2";
            this.clintButton2.ShadowDecoration.Parent = this.clintButton2;
            this.clintButton2.Size = new System.Drawing.Size(169, 37);
            this.clintButton2.TabIndex = 0;
            this.clintButton2.Text = "Client";
            this.clintButton2.Click += new System.EventHandler(this.clintButton2_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.guna2HtmlLabel1);
            this.panel3.Controls.Add(this.guna2Button1);
            this.panel3.Controls.Add(this.lblDate);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(3, -1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1073, 75);
            this.panel3.TabIndex = 49;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Sitka Display", 27F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(11, 5);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(468, 54);
            this.guna2HtmlLabel1.TabIndex = 9;
            this.guna2HtmlLabel1.Text = "AK Hotel Management System ";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("guna2Button1.BackgroundImage")));
            this.guna2Button1.BorderRadius = 17;
            this.guna2Button1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.White;
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(962, 35);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(81, 37);
            this.guna2Button1.TabIndex = 7;
            this.guna2Button1.Text = "Logout";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1046, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "x";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(251, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(415, 45);
            this.label1.TabIndex = 51;
            this.label1.Text = "Reservation Information";
            // 
            // reservation_tblTableAdapter
            // 
            this.reservation_tblTableAdapter.ClearBeforeFill = true;
            // 
            // ReservationInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 485);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.roomicb);
            this.Controls.Add(this.clientncb);
            this.Controls.Add(this.dateTimeOut);
            this.Controls.Add(this.dateTimein);
            this.Controls.Add(this.DateOut);
            this.Controls.Add(this.DateIn);
            this.Controls.Add(this.ResGridView);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ReservationSearchlbl);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.guna2CirclePictureBox1);
            this.Controls.Add(this.ResId);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ReservationInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReservationInfo";
            this.Load += new System.EventHandler(this.ReservationInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ResGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationtblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.akhotelDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView ResGridView;
        private System.Windows.Forms.Button button1;
        private Guna.UI2.WinForms.Guna2TextBox ReservationSearchlbl;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Button btnEdit;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox ResId;
        private System.Windows.Forms.Label DateIn;
        private System.Windows.Forms.Label DateOut;
        private System.Windows.Forms.DateTimePicker dateTimein;
        private System.Windows.Forms.DateTimePicker dateTimeOut;
        private System.Windows.Forms.ComboBox clientncb;
        private System.Windows.Forms.ComboBox roomicb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button roomButton5;
        private Guna.UI2.WinForms.Guna2Button reservation2Button4;
        private Guna.UI2.WinForms.Guna2Button staffButton3;
        private Guna.UI2.WinForms.Guna2Button clintButton2;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private akhotelDataSet3 akhotelDataSet3;
        private System.Windows.Forms.BindingSource reservationtblBindingSource;
        private akhotelDataSet3TableAdapters.Reservation_tblTableAdapter reservation_tblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn resIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateInDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOutDataGridViewTextBoxColumn;
    }
}