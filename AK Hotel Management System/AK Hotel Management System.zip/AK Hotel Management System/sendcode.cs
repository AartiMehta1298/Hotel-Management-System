﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace AK_Hotel_Management_System
{
    public partial class sendcode : Form
    {
        public sendcode()
        {
            InitializeComponent();
        }
        string otpcode;
        public static string to;

        private void sendcode_Load(object sender, EventArgs e)
        {

        }

        private void btnsend_Click(object sender, EventArgs e)
        {
            string from, pass, messageBody;
            Random rand = new Random();
            otpcode = (rand.Next(999999)).ToString();


            MailMessage message = new MailMessage();
            to = (txtemail.Text).ToString();
            from = "mehtaaarti520@gmail.com";
            pass = "n0Tpossible!";
            messageBody = "Your Reset OTP code is " + otpcode;
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = messageBody;
            message.Subject = "Forgot Password code";

            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);

            try
            {
                smtp.Send(message);
                MessageBox.Show("Code send successfully");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnverify_Click(object sender, EventArgs e)
        {
            if(otpcode == (txtotp.Text).ToString())
            {
                to = txtemail.Text;
                ChangePassword cp = new ChangePassword();
                cp.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("wrong code");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
